# 99co-homepage-automation

Mobile automation test suite for the 99.co app homepage, built with Appium, WebdriverIO, CommonJS, Page Object Model, and Gherkin.

## Setup

```bash
npm install
```

## Run

```bash
npm test
```
