class Page {
  open(path) {
    return browser.url(path);
  }

  async waitForDisplayed(selector) {
    const el = await $(selector);
    await el.waitForDisplayed({ timeout: 10000 });
    return el;
  }
}

module.exports = Page;
