const Page = require('./page');

class HomePage extends Page {
  get searchTab() {
    return $('//*[@text="Cari" or @content-desc="Cari"]');
  }

  get homeTab() {
    return $('//*[@text="Home" or @content-desc="Home"]');
  }

  get savedTab() {
    return $('//*[@text="Simpan" or @content-desc="Simpan"]');
  }

  get myListingTab() {
    return $('//*[@text="Iklan Saya" or @content-desc="Iklan Saya"]');
  }

  get notificationIcon() {
    return $('//*[@text="Notifikasi" or @content-desc="Notifikasi"]');
  }

  get rentMenu() {
    return $('//*[@text="Rent" or @content-desc="Rent"]');
  }

  get favoriteButton() {
    return $('//*[@text="Favorit" or @content-desc="Favorit"]');
  }

  async isDisplayed() {
    return this.homeTab.isDisplayed();
  }

  async tapSearchTab() {
    await this.searchTab.click();
  }

  async tapSavedTab() {
    await this.savedTab.click();
  }

  async tapMyListingTab() {
    await this.myListingTab.click();
  }
}

module.exports = new HomePage();
