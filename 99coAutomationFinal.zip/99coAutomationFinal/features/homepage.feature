Feature: Homepage 99.co (Revamp)
  Sebagai pengguna aplikasi 99.co
  Saya ingin membuka dan berinteraksi dengan homepage yang sudah direvamp
  Supaya saya bisa memastikan seluruh elemen utama berfungsi dengan baik

  Background:
    Given aplikasi 99.co sudah terbuka

  Scenario: Akses homepage
    When aplikasi selesai loading
    Then pengguna melihat halaman homepage

  Scenario: Homepage menampilkan tab Home
    Then pengguna melihat tab "Home"

  Scenario: Homepage menampilkan tab Search
    Then pengguna melihat tab "Cari"

  Scenario: Homepage menampilkan tab Saved
    Then pengguna melihat tab "Simpan"

  Scenario: Homepage menampilkan tab Iklan Saya
    Then pengguna melihat tab "Iklan Saya"

  Scenario: Pengguna dapat menekan tab Cari dari homepage
    When pengguna menekan tab "Cari"
    Then pengguna diarahkan ke halaman pencarian
