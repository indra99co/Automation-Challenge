exports.config = {
  runner: 'local',

  specs: ['./features/**/*.feature'],
  exclude: [],

  maxInstances: 1,
  capabilities: [
    {
      platformName: 'Android',
      'appium:deviceName': 'emulator-5554',
      'appium:automationName': 'UiAutomator2',
      'appium:app': './apps/com_urbanindo_android.apk',
      'appium:appPackage': 'com.urbanindo.android',
      'appium:appActivity': 'app.nine_nine.MainActivity',
      'appium:noReset': false,
    },
  ],

  logLevel: 'info',
  bail: 0,
  waitforTimeout: 10000,
  connectionRetryTimeout: 120000,
  connectionRetryCount: 3,

  services: ['appium'],

  framework: 'cucumber',

  reporters: ['spec'],

  cucumberOpts: {
    require: ['./step-definitions/**/*.js'],
    backtrace: false,
    requireModule: [],
    dryRun: false,
    failFast: false,
    snippets: true,
    source: true,
    strict: false,
    tagExpression: '',
    timeout: 60000,
    ignoreUndefinedDefinitions: false,
  },
};
