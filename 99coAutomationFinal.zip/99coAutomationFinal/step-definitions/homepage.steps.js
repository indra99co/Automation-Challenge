const { Given, When, Then } = require('@wdio/cucumber-framework');
const { expect } = require('@wdio/globals');
const HomePage = require('../pageobjects/home.page');

Given(/^aplikasi 99\.co sudah terbuka$/, async () => {
  await driver.pause(1000);
});

When(/^aplikasi selesai loading$/, async () => {
  await HomePage.homeTab.waitForDisplayed({ timeout: 10000 });
});

Then(/^pengguna melihat halaman homepage$/, async () => {
  const displayed = await HomePage.isDisplayed();
  expect(displayed).toBe(true);
});

Then(/^pengguna melihat tab "([^"]*)"$/, async (tabName) => {
  const map = {
    Home: HomePage.homeTab,
    Cari: HomePage.searchTab,
    Simpan: HomePage.savedTab,
    'Iklan Saya': HomePage.myListingTab,
  };
  await expect(map[tabName]).toBeDisplayed();
});

When(/^pengguna menekan tab "([^"]*)"$/, async (tabName) => {
  if (tabName === 'Cari') {
    await HomePage.tapSearchTab();
  } else if (tabName === 'Simpan') {
    await HomePage.tapSavedTab();
  } else if (tabName === 'Iklan Saya') {
    await HomePage.tapMyListingTab();
  }
});

Then(/^pengguna diarahkan ke halaman pencarian$/, async () => {
  const searchPage = await $('//*[@text="Hasil Pencarian" or @content-desc="Hasil Pencarian"]');
  await expect(searchPage).toBeDisplayed();
});
